package com.capgemini.capstore.main.service;

import java.io.IOException;

import com.capgemini.capstore.main.beans.Email;

public interface CapStoreEmailService {

	public Email generateNewEmail(String receiverEmailId, String receiverRole) throws IOException;

//	public Email updateEmail(String receiverEmailId, String receiverRole) throws IOException;

	public Email verifyEmail(String receiverEmailId, String receiverRole) throws IOException;
	
	public Email validateEmail(String receiverEmailId, String receiverRole) throws IOException;

	public Email afterVerification(String receiverEmailId, String otpNumber, String receiverRole) throws IOException;
}

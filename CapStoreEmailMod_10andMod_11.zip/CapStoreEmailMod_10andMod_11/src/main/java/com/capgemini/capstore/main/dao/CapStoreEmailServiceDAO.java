package com.capgemini.capstore.main.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.main.beans.Email;

@Repository
public interface CapStoreEmailServiceDAO extends JpaRepository<Email, Integer> {

	@Query("SELECT e from Email e WHERE receiverEmail=:receiverEmail AND status=:status")
	public List<Email> findAllReceiverEmails(@Param("receiverEmail") String receiverEmail,@Param("status") String status);
	
}

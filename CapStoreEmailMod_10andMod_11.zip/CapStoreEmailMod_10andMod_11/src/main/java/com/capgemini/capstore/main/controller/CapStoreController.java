package com.capgemini.capstore.main.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Email;
import com.capgemini.capstore.main.service.CapStoreEmailService;

@RestController
public class CapStoreController {

	@Autowired
	private CapStoreEmailService capStoreEmailService;

	@RequestMapping(method = RequestMethod.GET, value = "/")
	public Email generateEmail() throws IOException {
		return capStoreEmailService.generateNewEmail("xyz@gmail.com", "Customer");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/verify")
	public Email verifyEmail() throws IOException {
		return capStoreEmailService.verifyEmail("xyz@gmail.com", "Customer");
	}

	@RequestMapping(method = RequestMethod.GET, value = "/validate")
	public Email validateEmail() throws IOException {
		return capStoreEmailService.validateEmail("xyz@gmail.com", "Customer");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/verify1")
	public Email verify1Email() throws IOException {
		return capStoreEmailService.afterVerification("xyz@gmail.com","24356","Customer");
	}
	
}

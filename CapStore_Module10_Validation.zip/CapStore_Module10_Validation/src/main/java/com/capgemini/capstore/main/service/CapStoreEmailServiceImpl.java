package com.capgemini.capstore.main.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Email;
import com.capgemini.capstore.main.dao.CapStoreEmailServiceDAO;

@Service
public class CapStoreEmailServiceImpl implements CapStoreEmailService {

	@Autowired
	CapStoreEmailServiceDAO capStoreEmailServiceDAO;

	@Override
	public Email validateEmail(String receiverEmailId, String receiverRole) throws IOException {
		// call generateEmail for generating new email
		return capStoreEmailServiceDAO.findAllReceiverEmails(receiverEmailId, "N").get(0);
	}

	@Override
	public Email afterVerification(String receiverEmailId, String otpNumber, String receiverRole) throws IOException {
		List<Email> emails = capStoreEmailServiceDAO.findAllReceiverEmails(receiverEmailId, "N");
		for (Email email : emails) {
			// String otp = email.getBodyMessage().substring("");
			// if(otp.equals(otpNumber)){
			email.setStatus("Y");
			// generate verifyEmail after verification
			// }
		}
		return null;
	}

}
